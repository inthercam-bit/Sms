package com.ios.messages

import android.app.*
import android.content.*
import android.os.IBinder
import android.provider.Telephony
import androidx.core.app.NotificationCompat

class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val msgs = Telephony.Sms.Intents.getMessagesFromIntent(i) ?: return
        if (msgs.isEmpty()) return
        val addr = msgs[0].displayOriginatingAddress ?: return
        val body = msgs.joinToString("") { it.messageBody ?: "" }
        val v = ContentValues().apply {
            put(Telephony.Sms.ADDRESS, addr); put(Telephony.Sms.BODY, body)
            put(Telephony.Sms.DATE, System.currentTimeMillis()); put(Telephony.Sms.READ, 0)
            put(Telephony.Sms.TYPE, Telephony.Sms.MESSAGE_TYPE_INBOX)
        }
        runCatching { c.contentResolver.insert(Telephony.Sms.Inbox.CONTENT_URI, v) }
        runCatching {
            val nm = c.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel("sms", "Mesajlar", NotificationManager.IMPORTANCE_HIGH))
            val pi = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
            nm.notify(addr.hashCode(), NotificationCompat.Builder(c, "sms")
                .setSmallIcon(android.R.drawable.sym_action_chat).setContentTitle(nameFor(c, addr))
                .setContentText(body).setStyle(NotificationCompat.BigTextStyle().bigText(body))
                .setAutoCancel(true).setContentIntent(pi).build())
        }
    }
}

class MmsReceiver : BroadcastReceiver() { override fun onReceive(c: Context, i: Intent) {} }
class RespondService : Service() { override fun onBind(i: Intent?): IBinder? = null }
