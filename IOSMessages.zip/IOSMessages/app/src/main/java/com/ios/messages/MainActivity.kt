package com.ios.messages

import android.Manifest
import android.app.role.RoleManager
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.database.ContentObserver
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.ContactsContract
import android.provider.Telephony
import android.telephony.SmsManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.*

val Blue = Color(0xFF0A84FF); val Gray = Color(0xFF8E8E93); val Bubble = Color(0xFF2C2C2E)

data class Msg(val id: Long, val thread: Long, val addr: String, val body: String, val date: Long, val type: Int, val read: Boolean)

fun nameFor(c: Context, number: String): String = runCatching {
    c.contentResolver.query(Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number)),
        arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) it.getString(0) else null }
}.getOrNull() ?: number

fun query(c: Context, sel: String?, args: Array<String>?, order: String, max: Int): List<Msg> = runCatching {
    val out = mutableListOf<Msg>()
    c.contentResolver.query(Telephony.Sms.CONTENT_URI, arrayOf("_id", "thread_id", "address", "body", "date", "type", "read"), sel, args, order)?.use {
        while (it.moveToNext() && out.size < max)
            out.add(Msg(it.getLong(0), it.getLong(1), it.getString(2) ?: "", it.getString(3) ?: "", it.getLong(4), it.getInt(5), it.getInt(6) == 1))
    }
    out
}.getOrDefault(emptyList())

fun isDefault(c: Context) = c.getSystemService(RoleManager::class.java).isRoleHeld(RoleManager.ROLE_SMS)

fun send(c: Context, to: String, text: String) {
    if (to.isBlank() || text.isBlank()) return
    runCatching {
        val sm = c.getSystemService(SmsManager::class.java)
        sm.sendMultipartTextMessage(to, null, sm.divideMessage(text), null, null)
        if (isDefault(c)) {
            val v = ContentValues().apply {
                put(Telephony.Sms.ADDRESS, to); put(Telephony.Sms.BODY, text); put(Telephony.Sms.DATE, System.currentTimeMillis())
                put(Telephony.Sms.READ, 1); put(Telephony.Sms.TYPE, Telephony.Sms.MESSAGE_TYPE_SENT)
            }
            c.contentResolver.insert(Telephony.Sms.Sent.CONTENT_URI, v)
        }
    }
}

fun fmt(t: Long): String {
    val now = Calendar.getInstance(); val d = Calendar.getInstance().apply { timeInMillis = t }
    val sameDay = now.get(Calendar.YEAR) == d.get(Calendar.YEAR) && now.get(Calendar.DAY_OF_YEAR) == d.get(Calendar.DAY_OF_YEAR)
    return SimpleDateFormat(if (sameDay) "HH:mm" else "d MMM", Locale("tr")).format(Date(t))
}

class MainActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val num = intent?.data?.schemeSpecificPart?.substringBefore("?") ?: ""
        val body = intent?.getStringExtra("sms_body") ?: ""
        setContent { MaterialTheme(colorScheme = darkColorScheme(background = Color.Black, surface = Color.Black)) { App(num, body) } }
    }
}

@Composable
fun App(initNum: String, initBody: String) {
    val ctx = LocalContext.current
    val perms = arrayOf(Manifest.permission.READ_SMS, Manifest.permission.SEND_SMS, Manifest.permission.RECEIVE_SMS,
        Manifest.permission.READ_CONTACTS, Manifest.permission.POST_NOTIFICATIONS)
    fun has() = ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED
    var granted by remember { mutableStateOf(has()) }
    val permL = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { granted = has() }
    LaunchedEffect(Unit) { if (!granted) permL.launch(perms) }
    var isDef by remember { mutableStateOf(isDefault(ctx)) }
    val roleL = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { isDef = isDefault(ctx) }
    var ver by remember { mutableIntStateOf(0) }
    DisposableEffect(Unit) {
        val o = object : ContentObserver(Handler(Looper.getMainLooper())) { override fun onChange(s: Boolean) { ver++ } }
        ctx.contentResolver.registerContentObserver(Uri.parse("content://sms"), true, o)
        onDispose { ctx.contentResolver.unregisterContentObserver(o) }
    }
    var chat by remember { mutableStateOf<Pair<String, Long>?>(null) }
    var composing by remember { mutableStateOf(initNum.isNotEmpty()) }
    BackHandler(chat != null || composing) { chat = null; composing = false }

    Column(Modifier.fillMaxSize().background(Color.Black).statusBarsPadding()) {
        if (!isDef && chat == null) Row(Modifier.fillMaxWidth().padding(12.dp).clip(RoundedCornerShape(14.dp)).background(Bubble)
            .clickable { roleL.launch(ctx.getSystemService(RoleManager::class.java).createRequestRoleIntent(RoleManager.ROLE_SMS)) }
            .padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Varsayılan mesaj uygulaması yap", color = Color.White, fontWeight = FontWeight.SemiBold)
                Text("Gelen SMS'ler bu uygulamada açılsın", color = Gray, fontSize = 13.sp)
            }
            Text("Ayarla", color = Blue)
        }
        val c = chat
        when {
            c != null -> Chat(c.first, c.second, ver, granted) { chat = null }
            composing -> NewMsg(initNum, initBody, { composing = false }) { addr ->
                val t = runCatching { Telephony.Threads.getOrCreateThreadId(ctx, addr) }.getOrDefault(0L)
                composing = false; chat = addr to t
            }
            else -> Conversations(ver, granted, { composing = true }) { a, t -> chat = a to t }
        }
    }
}

@Composable
fun Avatar(name: String) = Box(Modifier.size(46.dp).clip(CircleShape).background(Color(0xFF636366)), contentAlignment = Alignment.Center) {
    Text(name.firstOrNull { it.isLetter() }?.uppercase() ?: "#", color = Color.White, fontSize = 19.sp)
}

@Composable
fun Conversations(ver: Int, granted: Boolean, onNew: () -> Unit, onOpen: (String, Long) -> Unit) {
    val ctx = LocalContext.current
    val convs = remember(ver, granted) {
        if (!granted) emptyList<Pair<Msg, Boolean>>() else query(ctx, null, null, "date DESC", 5000).groupBy { it.thread }
            .map { (_, l) -> l.first() to l.any { !it.read && it.type == 1 } }
    }
    Row(Modifier.fillMaxWidth().padding(16.dp, 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("Mesajlar", fontSize = 34.sp, fontWeight = FontWeight.Bold, color = Color.White, modifier = Modifier.weight(1f))
        Text("✎", fontSize = 28.sp, color = Blue, modifier = Modifier.clickable { onNew() }.padding(8.dp))
    }
    if (convs.isEmpty()) Text(if (granted) "Mesaj yok" else "SMS izni gerekli", color = Gray, modifier = Modifier.padding(16.dp))
    LazyColumn {
        items(convs) { (m, unread) ->
            val name = remember(m.addr) { nameFor(ctx, m.addr) }
            Row(Modifier.fillMaxWidth().clickable { onOpen(m.addr, m.thread) }.padding(16.dp, 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(10.dp).clip(CircleShape).background(if (unread) Blue else Color.Transparent))
                Spacer(Modifier.width(8.dp)); Avatar(name); Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Row { Text(name, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, modifier = Modifier.weight(1f))
                        Text(fmt(m.date), color = Gray, fontSize = 14.sp) }
                    Text(m.body, color = Gray, fontSize = 15.sp, maxLines = 2)
                }
            }
            Box(Modifier.padding(start = 80.dp).fillMaxWidth().height(1.dp).background(Color(0xFF1C1C1E)))
        }
    }
}

@Composable
fun Field(v: String, set: (String) -> Unit, hint: String, mod: Modifier = Modifier, kb: KeyboardOptions = KeyboardOptions.Default) =
    TextField(v, set, placeholder = { Text(hint) }, shape = RoundedCornerShape(20.dp), keyboardOptions = kb,
        colors = TextFieldDefaults.colors(focusedContainerColor = Bubble, unfocusedContainerColor = Bubble,
            focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent), modifier = mod)

@Composable
fun SendBtn(enabled: Boolean, onClick: () -> Unit) =
    Box(Modifier.size(38.dp).clip(CircleShape).background(if (enabled) Blue else Color(0xFF3A3A3C)).clickable(enabled = enabled) { onClick() },
        contentAlignment = Alignment.Center) { Text("↑", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold) }

@Composable
fun ColumnScope.Chat(addr: String, thread: Long, ver: Int, granted: Boolean, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val name = remember(addr) { nameFor(ctx, addr) }
    val msgs = remember(ver, granted) { if (thread > 0) query(ctx, "thread_id=?", arrayOf(thread.toString()), "date ASC", 5000) else emptyList() }
    val ls = rememberLazyListState()
    var text by remember { mutableStateOf("") }
    LaunchedEffect(ver) {
        runCatching { ctx.contentResolver.update(Telephony.Sms.CONTENT_URI, ContentValues().apply { put("read", 1) },
            "thread_id=? AND read=0", arrayOf(thread.toString())) }
    }
    LaunchedEffect(msgs.size) { if (msgs.isNotEmpty()) ls.scrollToItem(msgs.lastIndex) }
    Box(Modifier.fillMaxWidth().padding(12.dp), contentAlignment = Alignment.Center) {
        Text("‹ Mesajlar", color = Blue, fontSize = 17.sp, modifier = Modifier.align(Alignment.CenterStart).clickable { onBack() })
        Text(name, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, maxLines = 1,
            modifier = Modifier.padding(horizontal = 90.dp))
    }
    LazyColumn(Modifier.weight(1f).padding(horizontal = 12.dp), state = ls, verticalArrangement = Arrangement.spacedBy(4.dp)) {
        items(msgs, key = { it.id }) { m ->
            val mine = m.type != 1
            Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
                Text(m.body, color = Color.White, fontSize = 16.sp,
                    modifier = Modifier.widthIn(max = 290.dp).clip(RoundedCornerShape(18.dp)).background(if (mine) Blue else Bubble).padding(12.dp, 8.dp))
            }
        }
    }
    Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
        Field(text, { text = it }, "iMessage", Modifier.weight(1f)); Spacer(Modifier.width(8.dp))
        SendBtn(text.isNotBlank()) { send(ctx, addr, text); text = ""; }
    }
}

@Composable
fun ColumnScope.NewMsg(initNum: String, initBody: String, onBack: () -> Unit, onSent: (String) -> Unit) {
    val ctx = LocalContext.current
    var to by remember { mutableStateOf(initNum) }
    var text by remember { mutableStateOf(initBody) }
    Box(Modifier.fillMaxWidth().padding(12.dp), contentAlignment = Alignment.Center) {
        Text("İptal", color = Blue, fontSize = 17.sp, modifier = Modifier.align(Alignment.CenterStart).clickable { onBack() })
        Text("Yeni Mesaj", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
    }
    Field(to, { to = it }, "Kime: numara", Modifier.fillMaxWidth().padding(horizontal = 12.dp), KeyboardOptions(keyboardType = KeyboardType.Phone))
    Spacer(Modifier.weight(1f))
    Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
        Field(text, { text = it }, "iMessage", Modifier.weight(1f)); Spacer(Modifier.width(8.dp))
        SendBtn(text.isNotBlank() && to.isNotBlank()) { send(ctx, to.trim(), text); onSent(to.trim()) }
    }
}
